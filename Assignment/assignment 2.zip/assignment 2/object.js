let employee={
    Id:'101',
    name:'Arpita',
    salary:'30000',
    position:'Asociate software developer',

};
console.log(employee);
let key=Object.keys(employee);
console.log(key);
let value=Object.values(employee);
console.log(value)
let entires=Object.entries(employee);
console.log(entires)